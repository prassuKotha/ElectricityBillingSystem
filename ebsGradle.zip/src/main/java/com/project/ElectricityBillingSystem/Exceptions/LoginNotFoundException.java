package com.project.ElectricityBillingSystem.Exceptions;

public class LoginNotFoundException extends Exception {
	
	public LoginNotFoundException(String msg) {
		super(msg);

	}
}

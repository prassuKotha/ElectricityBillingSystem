package com.project.ElectricityBillingSystem.Exceptions;

public class PaymentInvalidCredentialsExceptions extends RuntimeException{
	
	public PaymentInvalidCredentialsExceptions(String msg) {
		super(msg);
	}

}

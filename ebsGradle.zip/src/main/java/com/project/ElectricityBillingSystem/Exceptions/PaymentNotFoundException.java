package com.project.ElectricityBillingSystem.Exceptions;

public class PaymentNotFoundException extends Exception {

	public PaymentNotFoundException(String msg) {
		super(msg);
	}
}

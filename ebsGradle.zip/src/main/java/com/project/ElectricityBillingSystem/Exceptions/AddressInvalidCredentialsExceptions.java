package com.project.ElectricityBillingSystem.Exceptions;

public class AddressInvalidCredentialsExceptions extends RuntimeException{
	
	public AddressInvalidCredentialsExceptions(String msg) {
		super(msg);
	}

}

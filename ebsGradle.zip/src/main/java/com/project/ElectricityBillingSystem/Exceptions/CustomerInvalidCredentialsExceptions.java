package com.project.ElectricityBillingSystem.Exceptions;

public class CustomerInvalidCredentialsExceptions extends RuntimeException{
	
	public CustomerInvalidCredentialsExceptions(String msg) {
		super(msg);
	}

}

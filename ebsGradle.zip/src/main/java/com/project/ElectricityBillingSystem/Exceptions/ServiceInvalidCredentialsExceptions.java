package com.project.ElectricityBillingSystem.Exceptions;

public class ServiceInvalidCredentialsExceptions extends RuntimeException{
	
	public ServiceInvalidCredentialsExceptions(String msg) {
		super(msg);
	}

}

package com.project.ElectricityBillingSystem.Exceptions;

public class AddressNotFoundException extends Exception {
	
	public AddressNotFoundException(String msg) {
		super(msg);
	}

}

package com.project.ElectricityBillingSystem.Exceptions;

public class AminInvalidCredentialsExceptions extends RuntimeException{
	
	public AminInvalidCredentialsExceptions(String msg) {
		super(msg);
	}

}

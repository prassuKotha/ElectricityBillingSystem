package com.project.ElectricityBillingSystem.Exceptions;

public class BillingNotFoundException extends Exception{
	public BillingNotFoundException(String msg) {
		super(msg);
	}
}

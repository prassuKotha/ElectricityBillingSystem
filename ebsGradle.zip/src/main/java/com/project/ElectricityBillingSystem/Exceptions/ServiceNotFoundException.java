package com.project.ElectricityBillingSystem.Exceptions;

public class ServiceNotFoundException extends Exception{
	
	public ServiceNotFoundException(String msg) {
		super(msg);
	}

}

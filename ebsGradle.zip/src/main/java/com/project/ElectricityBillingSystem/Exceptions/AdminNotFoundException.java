package com.project.ElectricityBillingSystem.Exceptions;

public class AdminNotFoundException extends Exception{

	public AdminNotFoundException(String msg) {
		super(msg);
	}
}

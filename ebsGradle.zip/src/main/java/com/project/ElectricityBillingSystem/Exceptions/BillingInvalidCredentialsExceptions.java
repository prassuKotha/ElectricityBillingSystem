package com.project.ElectricityBillingSystem.Exceptions;

public class BillingInvalidCredentialsExceptions extends RuntimeException{
	
	public BillingInvalidCredentialsExceptions(String msg) {
		super(msg);
	}

}

package com.project.ElectricityBillingSystem.Exceptions;

public class LoginInvalidCredentialsExceptions extends RuntimeException{
	
	public LoginInvalidCredentialsExceptions(String msg) {
		super(msg);
	}

}
